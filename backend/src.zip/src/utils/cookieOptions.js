const isProduction = process.env.NODE_ENV === "production";

export const accessTokenCookieOptions = Object.freeze({
    httpOnly: true,
    secure: isProduction,
    sameSite: isProduction ? "none" : "lax",
    maxAge: 15 * 60 * 1000
});

export const refreshTokenCookieOptions = Object.freeze({
    httpOnly: true,
    secure: isProduction,
    sameSite: isProduction ? "none" : "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000
});